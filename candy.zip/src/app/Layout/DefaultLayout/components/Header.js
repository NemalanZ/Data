import React from 'react'
import { Link } from 'react-router-dom'
import IMAGEROUTER from '../../../../routes/ImgRouters'

const Header = ({ onMenuClick, userName }) => {
  // const handlesidebar = () => {
  //   document.body.classList.toggle('mini-sidebar')
  // }
  const onMenuClik = () => {
    onMenuClick()
  }

  return (
    <div className='header' style={{ right: '0px' }}>
      {/* Logo */}
      <Link to='dashboard' className='logo'>
        <div className='header-left'>
          <img src={IMAGEROUTER.headerlogo} width={35} height={40} alt='' />
          <div className='page-title-box'>
            <h3>qBotica</h3>
          </div>
        </div>
      </Link>
      {/* /Logo */}
      {/* <a id="toggle_btn" href="#" onClick={handlesidebar}>
        <span className="bar-icon"><span />
          <span />
          <span />
        </span>
      </a> */}
      {/* Header Title */}
      {/* <div className='page-title-box'>
        <h3>qBotica</h3>
      </div> */}
      {/* /Header Title */}
      <a
        id='mobile_btn'
        className='mobile_btn'
        href='#'
        onClick={() => onMenuClik()}
      >
        <i className='fa fa-bars' />
      </a>
      {/* Header Menu */}
      <ul className='nav user-menu'>
        <li className='nav-item dropdown has-arrow main-drop'>
          <a
            href='#'
            className='dropdown-toggle nav-link'
            data-bs-toggle='dropdown'
          >
            <span className='user-img me-1'>
              <img src={IMAGEROUTER.Avatar} alt='' />
              {/* <span className='status online' /> */}
            </span>
            <span>Admin</span>
          </a>
          <div className='dropdown-menu'>
            {/* <Link className="dropdown-item" to="/app/profile/employee-profile">My Profile</Link> */}
            {/* <Link className="dropdown-item" to="/settings/companysetting">Settings</Link> */}
            <Link className='dropdown-item' to='/auth/login'>
              Logout
            </Link>
          </div>
        </li>
      </ul>
      {/* /Header Menu */}
      {/* Mobile Menu */}
      <div className='dropdown mobile-user-menu'>
        <a
          href='#'
          className='nav-link dropdown-toggle'
          data-bs-toggle='dropdown'
          aria-expanded='false'
        >
          <i className='fa fa-ellipsis-v' />
        </a>
        <div className='dropdown-menu dropdown-menu-right'>
          {/* <Link className="dropdown-item" to="/app/profile/employee-profile">My Profile</Link>
          <Link className="dropdown-item" to="/settings/companysetting">Settings</Link> */}
          <Link className='dropdown-item' to='/auth/login'>
            Logout
          </Link>
        </div>
      </div>
      {/* /Mobile Menu */}
    </div>
  )
}

export default Header
