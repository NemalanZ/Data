import { loginRedux, getUserName } from '../../../../redux/reducers/userReducer'
import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import LoginComponent from './Login.Component'

const mapStateToProps = createStructuredSelector({
  userName: getUserName
  // error: getError,
  // loading: isLoading,
  // loginType: getLoginType,
})

const mapDispatchToProps = {
  loginRedux
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent)
