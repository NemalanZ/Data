const IMAGEROUTER = {
  headerlogo: require('../assets/img/logo.png'),
  AppLogo: require('../assets/img/logo-color.png'),
  Avatar: require('../assets/img/profiles/avatar.jpg'),
  User: require('../assets/img/user.jpg'),
  Img_01: require('../assets/img/img-01.jpg'),
  PlaceHolder: require('../assets/img/placeholder.jpg'),
  Attachment: require('../assets/img/attachment.png'),
  Video_Call: require('../assets/img/video-call.jpg')
}

export default IMAGEROUTER
