import { defaultTo, equals, filter, find, prop, propEq } from 'ramda'
import { createSelector } from 'reselect'
import getClientsApi from '../../api/getClient'
import getClientAddressApi from '../../api/getClientAddress'
import getJobDetailsApi from '../../api/getJobDetails'
import getJobTypesApi from '../../api/getJobType'
import putJobApi from '../../api/putJob'
import { EDIT_JOB_ACTION as ACTIONS } from '../actions'

const initialState = {
  error: null,
  loading: false,
  jobDetails: [],
  jobId: '',
  requisitionId: '',
  dateOfRequisition: '',
  jobTitle: '',
  jobType: '',
  jobStatus: '',
  client: '',
  address: '',
  city: '',
  pinCode: '',
  country: '',
  state: '',
  experience: '',
  vacancyCount: '',
  minSalary: '',
  maxSalary: '',
  jobDescriptionFilePath: '',
  jobDescriptionText: '',
  archived: false,

  jobTypes: [],
  clients: [],
  clientAddress: [],
  selectedClient: []
  // cities: [],
  // states: [],
  // countries: [],
}

const getSlice = prop('editJob')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getJobDetails = createSelector(getSlice, prop('jobDetails'))
export const getJobId = createSelector(getSlice, prop('jobId'))
export const getRequisitionId = createSelector(getSlice, prop('requisitionId'))
export const getDateOfRequisition = createSelector(
  getSlice,
  prop('dateOfRequisition')
)
export const getJobTitle = createSelector(getSlice, prop('jobTitle'))
export const getJobType = createSelector(getSlice, prop('jobType'))
export const getJobStatus = createSelector(getSlice, prop('jobStatus'))
export const getClient = createSelector(getSlice, prop('client'))
export const getAddress = createSelector(getSlice, prop('address'))
export const getCity = createSelector(getSlice, prop('city'))
export const getPinCode = createSelector(getSlice, prop('pinCode'))
export const getStateValue = createSelector(getSlice, prop('state'))
export const getCountry = createSelector(getSlice, prop('country'))
export const getExperience = createSelector(getSlice, prop('experience'))
export const getVacancyCount = createSelector(getSlice, prop('vacancyCount'))
export const getMinSalary = createSelector(getSlice, prop('minSalary'))
export const getMaxSalary = createSelector(getSlice, prop('maxSalary'))
export const getJobDescriptionFilePath = createSelector(
  getSlice,
  prop('jobDescriptionFilePath')
)
export const getJobDescriptionText = createSelector(
  getSlice,
  prop('jobDescriptionText')
)
export const getArchived = createSelector(getSlice, prop('archived'))

// MASTER TABLE
export const getJobTypes = createSelector(getSlice, prop('jobTypes'))
export const getClients = createSelector(getSlice, prop('clients'))
export const getClientAddress = createSelector(getSlice, prop('clientAddress'))
export const getSelectedClient = createSelector(
  getSlice,
  prop('selectedClient')
)
// export const getCities = createSelector(getSlice, prop('cities'));
// export const getStates = createSelector(getSlice, prop('states'));
// export const getCountries = createSelector(getSlice, prop('countries'));

export const fetchPrevJobDetails = (id) => async (dispatch) => {
  dispatch({
    type: ACTIONS.PREV_JOB_DETAILS_REQUEST
  })
  try {
    const prevJobDetailsData = await getJobDetailsApi(id)
    dispatch({
      type: ACTIONS.PREV_JOB_DETAILS_SUCCESS,
      data: prevJobDetailsData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.PREV_JOB_DETAILS_FAILURE,
      error
    })
  }
}

export const fetchMasterData = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.JOB_MASTER_DATA_ACTION_REQUEST
  })
  try {
    const jobTypesData = await getJobTypesApi()
    const clientsData = await getClientsApi()
    const clientAddressData = await getClientAddressApi()
    // const citiesData = await getCitiesApi();
    // const statesData = await getStatesApi();
    // const countriesData = await getCountriesApi();

    const data = {
      jobTypesData,
      clientsData,
      clientAddressData
      // citiesData,
      // statesData,
      // countriesData,
    }
    // console.log('masterData', data)
    dispatch({
      type: ACTIONS.JOB_MASTER_DATA_ACTION_SUCCESS,
      masterData: data
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.JOB_MASTER_DATA_ACTION_FAILURE,
      error
    })
  }
}

export const putJob = (id, navigate) => async (dispatch, getState) => {
  dispatch({
    type: ACTIONS.PUT_JOB_REQUEST
  })
  try {
    const payload = {
      requisition_id: getRequisitionId(getState()),
      date_of_requisition: getDateOfRequisition(getState()),
      job_title: getJobTitle(getState()),
      job_type: getJobType(getState()),
      job_status: getJobStatus(getState()),
      client: getClient(getState()),
      address: getAddress(getState()),
      city_id: getCity(getState()),
      pin_code: getPinCode(getState()),
      state_id: getStateValue(getState()),
      country_id: getCountry(getState()),
      experience: getExperience(getState()),
      vacancy_count: getVacancyCount(getState()),
      min_salary: getMinSalary(getState()),
      max_salary: getMaxSalary(getState()),
      job_description_file_path: getJobDescriptionFilePath(getState()),
      job_description_text: getJobDescriptionText(getState()),
      archived: getArchived(getState())
    }
    const putJobData = await putJobApi(payload, id)
    // console.log(putJobData);
    dispatch({
      type: ACTIONS.PUT_JOB_SUCCESS,
      data: putJobData,
      payload
    })
    if (
      equals(
        'Job Posting updated successfully',
        prop('response_message', putJobData)
      )
    ) {
      navigate('/jobs')
    } else {
      dispatch({
        type: ACTIONS.PUT_JOB_FAILURE,
        error: putJobData.response_message
      })
    }
  } catch (error) {
    dispatch({
      type: ACTIONS.PUT_JOB_FAILURE,
      error
    })
  }
}

export const setRequisitionId = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_REQUISITION_ID,
    value: defaultTo('', value)
  })
}
export const setDateOfRequisition = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_DATE_OF_REQUISITION,
    value: defaultTo('', value)
  })
}
export const setJobTitle = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_TITLE,
    value: defaultTo('', value)
  })
}
export const setJobStatus = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_STATUS,
    value: defaultTo('', value)
  })
}
export const setJobType = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_TYPE,
    value: defaultTo('', value)
  })
}
export const setClient = (value) => (dispatch, getState) => {
  const clientAddresses = getClientAddress(getState())
  const findClientDetails = filter(
    propEq('client_id', Number(value)),
    clientAddresses
  )
  // console.log("clientAddresses===>", clientAddresses)
  // console.log("findClientDetails===>", findClientDetails)
  // console.log("values===>", value)
  dispatch({
    type: ACTIONS.SET_CLIENT,
    value: defaultTo('', value),
    details: findClientDetails
  })
}
export const setAddress = (value) => (dispatch, getState) => {
  const selectedClient = getSelectedClient(getState())
  const findClientAdress = find(propEq('address', value), selectedClient)
  // console.log('selectedClient==>', selectedClient)
  dispatch({
    type: ACTIONS.SET_ADDRESS,
    value: defaultTo('', value),
    details: findClientAdress
  })
}
export const setCity = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_CITY,
    value: defaultTo('', value)
  })
}
export const setPinCode = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_PIN_CODE,
    value: defaultTo('', value)
  })
}
export const setState = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_STATE,
    value: defaultTo('', value)
  })
}
export const setCountry = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_COUNTRY,
    value: defaultTo('', value)
  })
}
export const setExperience = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_EXPERIENCE,
    value: defaultTo('', value)
  })
}
export const setVacancyCount = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_VACANCY_COUNT,
    value: defaultTo('', value)
  })
}
export const setMinSalary = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_MIN_SALARY,
    value: defaultTo('', value)
  })
}
export const setMaxSalary = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_MAX_SALARY,
    value: defaultTo('', value)
  })
}
export const setJobDescriptionFilePath = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_DESCRIPTION_FILE_PATH,
    value: defaultTo('', value)
  })
}
export const setJobDescriptiontext = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_DESCRIPTION_TEXT,
    value: defaultTo('', value)
  })
}
export const setArchived = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_ARCHIVED,
    value: defaultTo('', value)
  })
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.JOB_MASTER_DATA_ACTION_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.JOB_MASTER_DATA_ACTION_SUCCESS:
      return {
        ...state,
        masterData: action.masterData,
        jobTypes: action.masterData.jobTypesData,
        clients: action.masterData.clientsData,
        clientAddress: action.masterData.clientAddressData,
        loading: false,
        error: false
      }
    case ACTIONS.JOB_MASTER_DATA_ACTION_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.PREV_JOB_DETAILS_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.PREV_JOB_DETAILS_SUCCESS: {
      return {
        ...state,
        jobDetails: action.data,
        jobId: prop('job_id', action.data),
        requisitionId: prop('requisition_id', action.data),
        dateOfRequisition: prop('date_of_requisition', action.data),
        jobTitle: prop('job_title', action.data),
        jobType: prop('job_type', action.data),
        jobStatus: prop('job_status', action.data),
        client: prop('client', action.data),
        address: prop('address', action.data),
        city: prop('city', action.data),
        pinCode: prop('pin_code', action.data),
        country: prop('country', action.data),
        state: prop('state', action.data),
        experience: prop('experience', action.data),
        vacancyCount: prop('vacancy_count', action.data),
        minSalary: prop('min_salary', action.data),
        maxSalary: prop('max_salary', action.data),
        jobDescriptionFilePath: prop('job_description_file_path', action.data),
        jobDescriptionText: prop('job_description_text', action.data),
        archived: prop('archived', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.PREV_JOB_DETAILS_FAILURE: {
      return {
        ...state,
        error: action.error,
        location: false
      }
    }
    case ACTIONS.PUT_JOB_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.PUT_JOB_SUCCESS: {
      return {
        ...state,
        requisitionId: prop('requisitionId', action.data),
        dateOfRequisition: prop('dateOfRequisition', action.data),
        jobTitle: prop('jobTitle', action.data),
        jobType: prop('jobType', action.data),
        jobStatus: prop('jobStatus', action.data),
        client: prop('client', action.data),
        address: prop('address', action.data),
        city: prop('city', action.data),
        pinCode: prop('pinCode', action.data),
        state: prop('state', action.data),
        country: prop('country', action.data),
        experience: prop('experience', action.data),
        vacancyCount: prop('vacancyCount', action.data),
        minSalary: prop('minSalary', action.data),
        maxSalary: prop('maxSalary', action.data),
        jobDescriptionFilePath: prop('jobDescriptionFilePath', action.data),
        jobDescriptionText: prop('jobDescriptionText', action.data),
        archived: prop('archived', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.PUT_JOB_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.SET_REQUISITION_ID: {
      return {
        ...state,
        requisitionId: action.value
      }
    }
    case ACTIONS.SET_DATE_OF_REQUISITION: {
      return {
        ...state,
        dateOfRequisition: action.value
      }
    }
    case ACTIONS.SET_JOB_TITLE: {
      return {
        ...state,
        jobTitle: action.value
      }
    }
    case ACTIONS.SET_JOB_TYPE: {
      return {
        ...state,
        jobType: action.value
      }
    }
    case ACTIONS.SET_JOB_STATUS: {
      return {
        ...state,
        jobStatus: action.value
      }
    }
    case ACTIONS.SET_CLIENT: {
      return {
        ...state,
        client: action.value,
        selectedClient: action.details,
        pinCode: '',
        city: '',
        state: '',
        country: ''
      }
    }
    case ACTIONS.SET_ADDRESS: {
      return {
        ...state,
        address: action.value,
        pinCode: prop('pin_code', action.details),
        city: prop('city_id', action.details),
        state: prop('state_id', action.details),
        country: prop('country_id', action.details)
      }
    }
    case ACTIONS.SET_CITY: {
      return {
        ...state,
        city: action.value
      }
    }
    case ACTIONS.SET_PIN_CODE: {
      return {
        ...state,
        pinCode: action.value
      }
    }
    case ACTIONS.SET_STATE: {
      return {
        ...state,
        state: action.value
      }
    }
    case ACTIONS.SET_COUNTRY: {
      return {
        ...state,
        country: action.value
      }
    }
    case ACTIONS.SET_EXPERIENCE: {
      return {
        ...state,
        experience: action.value
      }
    }
    case ACTIONS.SET_VACANCY_COUNT: {
      return {
        ...state,
        vacancyCount: action.value
      }
    }
    case ACTIONS.SET_MIN_SALARY: {
      return {
        ...state,
        minSalary: action.value
      }
    }
    case ACTIONS.SET_MAX_SALARY: {
      return {
        ...state,
        maxSalary: action.value
      }
    }
    case ACTIONS.SET_JOB_DESCRIPTION_FILE_PATH: {
      return {
        ...state,
        jobDescriptionFilePath: action.value
      }
    }
    case ACTIONS.SET_JOB_DESCRIPTION_TEXT: {
      return {
        ...state,
        jobDescriptionText: action.value
      }
    }
    case ACTIONS.SET_ARCHIVED: {
      return {
        ...state,
        archived: action.value
      }
    }
    default:
      return initialState
  }
}
