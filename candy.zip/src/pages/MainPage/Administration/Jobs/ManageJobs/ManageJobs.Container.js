import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import { fetchAllJobs, getAllJobs, deleteJob, isLoading } from '../../../../../redux/reducers/jobsReducer'
import Component from './ManageJobs.Component'

const mapStateToProps = createStructuredSelector({
  allJobs: getAllJobs,
  loading: isLoading
})

const mapDispatchToProps = {
  fetchAllJobs,
  deleteJob
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
