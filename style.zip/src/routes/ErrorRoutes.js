import React, { lazy } from 'react'

const ErrorPage = lazy(() => import('../pages/MainPage/Pages/ErrorPage/error404'))

const ErrorRoutes = {
  path: '*',
  element: <ErrorPage />,
  children: [
    {
      index: true
    }
  ]
}

export default ErrorRoutes
