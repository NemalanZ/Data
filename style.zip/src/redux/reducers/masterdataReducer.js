import { prop } from 'ramda'
import { createSelector } from 'reselect'
// import getJobTitles from '../../api/getJobTitle';
import getCitiesApi from '../../api/getCities'
import getClientsApi from '../../api/getClient'
import getCountriesApi from '../../api/getCountries'
import getJobTypesApi from '../../api/getJobType'
import getStatesApi from '../../api/getStates'
// import getLocations from '../../api/getLocations';

import { MASTER_DATA_ACTION as ACTIONS } from '../actions'

const initialState = {
  // jobTitles: [],
  jobTypes: [],
  clients: [],
  cities: [],
  states: [],
  countries: []
  // skills: [],
  // allLocations: [],
  // roles: [],
  // masterData: []
}

const getSlice = prop('masterData')

// export const getJobTitles = createSelector(getSlice, prop('jobTitles'));
export const getJobTypes = createSelector(getSlice, prop('jobTypes'))
export const getClients = createSelector(getSlice, prop('clients'))
export const getCities = createSelector(getSlice, prop('cities'))
export const getStates = createSelector(getSlice, prop('states'))
export const getCountries = createSelector(getSlice, prop('countries'))
// export const getSkills = createSelector(getSlice, prop('skills'));
// export const getLocations = createSelector(getSlice, prop('allLocations'));
// export const getRoles = createSelector(getSlice, prop('roles'));

export const fetchMasterData = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.MASTER_DATA_ACTION_REQUEST
  })
  try {
    // const jobtitles = await getJobTitles();
    const jobTypesData = await getJobTypesApi()
    const clientsData = await getClientsApi()
    const citiesData = await getCitiesApi()
    const statesData = await getStatesApi()
    const countriesData = await getCountriesApi()
    // const locations = await getLocations();
    // const roles = await getUserRoles();
    // const skills = await getSkills();

    const data = {
      // jobtitles,
      jobTypesData,
      clientsData,
      citiesData,
      statesData,
      countriesData
      // locations,
      // roles,
      // skills,
    }
    // console.log('masterData', data)
    dispatch({
      type: ACTIONS.MASTER_DATA_ACTION_SUCCESS,
      masterData: data
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.MASTER_DATA_ACTION_FAILURE,
      error
    })
  }
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.MASTER_DATA_ACTION_SUCCESS:
      return {
        ...state,
        masterData: action.masterData,
        // jobTitles: action.masterData.jobtitles,
        jobTypes: action.masterData.jobTypesData,
        clients: action.masterData.clientsData,
        cities: action.masterData.citiesData,
        states: action.masterData.statesData,
        countries: action.masterData.countriesData
        // skills: action.masterData.skills,
        // allLocations: action.masterData.locations,
        // roles: action.masterData.roles,
      }

    default:
      return initialState
  }
}
