import { createSelector } from 'reselect'
import { prop, reverse } from 'ramda'
import { JOBS_ACTION as ACTIONS } from '../actions'
import getAllJobsApi from '../../api/getAllJobs'
import deleteJobApi from '../../api/deleteJob'

const initialState = {
  error: null,
  loading: false,
  allJobs: []
}

const getSlice = prop('jobs')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getAllJobs = createSelector(getSlice, prop('allJobs'))
export const getJobId = createSelector(getSlice, prop('jobId'))

export const fetchAllJobs = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.GET_ALL_JOBS_REQUEST
  })
  try {
    const alljobsData = await getAllJobsApi()
    // console.log("alljobsData==>", alljobsData);
    dispatch({
      type: ACTIONS.GET_ALL_JOBS_SUCCESS,
      data: alljobsData
    })
    // console.log("alljobs==>",alljobsData)
  } catch (error) {
    dispatch({
      type: ACTIONS.GET_ALL_JOBS_FAILURE,
      error
    })
  }
}

export const deleteJob = (id) => async (dispatch) => {
  dispatch({
    type: ACTIONS.DELETE_JOB_REQUEST
  })
  try {
    const deleteJobData = await deleteJobApi(id)
    dispatch({
      type: ACTIONS.DELETE_JOB_SUCCESS,
      data: deleteJobData
    })
    dispatch(fetchAllJobs())
  } catch (error) {
    dispatch({
      type: ACTIONS.DELETE_JOB_FAILURE,
      error
    })
  }
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.GET_ALL_JOBS_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.GET_ALL_JOBS_SUCCESS: {
      // console.log("action==>",action)
      return {
        ...state,
        allJobs: reverse(action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.GET_ALL_JOBS_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.DELETE_JOB_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.DELETE_JOB_SUCCESS: {
      return {
        ...state,
        loading: false,
        error: false
      }
    }
    case ACTIONS.DELETE_JOB_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    default:
      return initialState
  }
}
