import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import { fetchDashboardData, getAllJobs, getAllCandidates, getAllClients, getSliceJobs, getSliceCandidates } from '../../../../../redux/reducers/dashboardReducer'
import Component from './JobDashboard.Component'

const mapStateToProps = createStructuredSelector({
  allCandidates: getAllCandidates,
  allJobs: getAllJobs,
  clients: getAllClients,
  sliceJobs: getSliceJobs,
  sliceCandidates: getSliceCandidates
})

const mapDispatchToProps = {
  fetchDashboardData
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
