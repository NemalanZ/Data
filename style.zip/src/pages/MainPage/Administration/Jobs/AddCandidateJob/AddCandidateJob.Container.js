import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import {
  fetchMasterData, getJobId, getJobTitle, getAddress, getCities, getCity, getCountries, getCountry, getEmailId, getExperience, getFirstName, getGender, getLastName, getMainSkill, getPhone, getPinCode, getResume, getSecondarySkill, getSkills, getStates, getStateValue, getJobDetails, getCandidateRounds, getCandidateStatus, postCandidate, setAddress,
  setCity, setCountry, setEmailId, setExperience, setFirstName, setGender, setLastName, setMainSkill, setPhone, setPinCode, setResume, setSecondarySkill, setState, setJobTitle, setRounds, setStatus, getRounds, getStatus
} from '../../../../../redux/reducers/addCandidateReducer'
import Component from './AddCandidateJob.Component'

const mapStateToProps = createStructuredSelector({
  jobId: getJobId,
  jobTitle: getJobTitle,
  firstName: getFirstName,
  lastName: getLastName,
  gender: getGender,
  emailId: getEmailId,
  phone: getPhone,
  experience: getExperience,
  mainSkill: getMainSkill,
  secondarySkill: getSecondarySkill,
  address: getAddress,
  city: getCity,
  pinCode: getPinCode,
  state: getStateValue,
  country: getCountry,
  rounds: getRounds,
  status: getStatus,
  resume: getResume,
  skills: getSkills,
  cities: getCities,
  states: getStates,
  countries: getCountries,
  candidateRounds: getCandidateRounds,
  candidateStatus: getCandidateStatus,
  jobDetails: getJobDetails
})

const mapDispatchToProps = {
  postCandidate,
  fetchMasterData,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setJobTitle,
  setRounds,
  setStatus,
  setResume
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
