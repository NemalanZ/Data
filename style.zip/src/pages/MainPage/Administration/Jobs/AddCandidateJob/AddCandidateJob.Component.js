import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate, useParams } from 'react-router-dom'

const AddCandidate = ({
  postCandidate,
  fetchMasterData,
  jobId,
  jobTitle,
  firstName,
  lastName,
  gender,
  emailId,
  phone,
  experience,
  mainSkill,
  secondarySkill,
  address,
  city,
  pinCode,
  state,
  country,
  rounds,
  status,
  resume,
  skills,
  cities,
  states,
  countries,
  jobDetails,
  setJobTitle,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setResume,
  candidateRounds,
  candidateStatus,
  setRounds,
  setStatus
}) => {
  const navigate = useNavigate()
  const { id } = useParams()
  console.log('jobDetails==>', jobDetails)
  console.log('cities==>', cities)

  useEffect(() => {
    fetchMasterData(id)
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    postCandidate(navigate)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Create Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Add Candidate</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'>
                      <Link to='/candidates'>Candidates</Link>
                    </li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <form>
              <div className='row'>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>
                      Job Id
                    </label>
                    <input
                      type='text'
                      name='requisitionId'
                      className='form-control'
                      value={jobId}
                      readOnly
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>First Name</label>
                    <input
                      name='firstName'
                      className='form-control'
                      type='text'
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Last Name</label>
                    <input
                      name='lastName'
                      value={lastName}
                      className='form-control '
                      type='text'
                      onChange={(e) => setLastName(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Gender</label>
                    <select
                      name='gender'
                      className='form-control3'
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {/* <option>
                        Select
                      </option> */}
                      <option>Male</option>
                      <option>Female</option>
                      {/* <option>Other</option> */}
                    </select>
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Contact</h4>
              </div>
              <div className='row'>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Email</label>
                    <input
                      name='emailId'
                      value={emailId}
                      className='form-control '
                      type='email'
                      onChange={(e) => setEmailId(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Phone</label>
                    <input
                      name='phone'
                      value={phone}
                      className='form-control'
                      type='number'
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Address</h4>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <label>Address</label>
                    <input
                      name='address'
                      value={address}
                      className='form-control'
                      type='text'
                      onChange={(e) => setAddress(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Pin Code</label>
                    <input
                      name='state'
                      value={pinCode}
                      className='form-control'
                      type='text'
                      onChange={(e) => setPinCode(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>City</label>
                    <select
                      name='city'
                      value={city}
                      className='form-control3'
                      onChange={(e) => {
                        setCity(e.target.value)
                        // setCountry(e.target.value);
                        // setState(e.target.value);
                      }}
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        cities.map((get) => (
                          <option key={get.city_id} value={get.city_id}>
                            {' '}
                            {get.city_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>

                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>State</label>
                    <select
                      name='state'
                      value={state}
                      className='form-control3'
                      onChange={(e) => setState(e.target.value)}
                      // disabled
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        states.map((get) => (
                          <option key={get.state_id} value={get.state_id}>
                            {' '}
                            {get.state_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Country</label>
                    <select
                      name='country'
                      value={country}
                      className='form-control3'
                      onChange={(e) => setCountry(e.target.value)}
                      // disabled
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        countries.map((get) => (
                          <option key={get.country_id} value={get.country_id}>
                            {' '}
                            {get.country_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Experience & Skills</h4>
              </div>
              <div className='row'>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Year of Experience</label>
                    <input
                      name='experience'
                      value={experience}
                      className='form-control'
                      type='text'
                      onChange={(e) => setExperience(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Main Skill</label>
                    <select
                      name='mainSkill'
                      value={mainSkill}
                      className='form-control3'
                      onChange={(e) => setMainSkill(e.target.value)}
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        skills.map((get) => (
                          <option key={get.skill_id} value={get.skill_id}>
                            {' '}
                            {get.skill_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Secondary Skill</label>
                    <input
                      name='secondarySkill'
                      value={secondarySkill}
                      className='form-control'
                      type='text'
                      onChange={(e) => setSecondarySkill(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Status</h4>
              </div>
              <div className='row'>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Rounds</label>
                    <select
                      name='rounds'
                      value={rounds}
                      className='form-control3'
                      onChange={(e) => setRounds(e.target.value)}
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        candidateRounds.map((get) => (
                          <option key={get.selection_status_id} value={get.selection_status_id}>
                            {' '}
                            {get.selection_status_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Status</label>
                    <select
                      name='status'
                      value={status}
                      className='form-control3'
                      onChange={(e) => setStatus(e.target.value)}
                      required
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {[
                        candidateStatus.map((get) => (
                          <option key={get.profile_status_id} value={get.profile_status_id}>
                            {' '}
                            {get.profile_status_name}
                          </option>
                        ))
                      ]}
                    </select>
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <label>Resume</label>
                    <input
                      className='form-control'
                      type='file'
                      id='fileInput'
                      value={resume}
                      onChange={(e) => setResume(e.target.value)}
                      accept='.pdf'
                    // required
                    />
                  </div>
                </div>
              </div>
              <div className='submit-section'>
                <button
                  type='button'
                  className='btn btn-primary submit-btn'
                  onClick={handleSubmit}
                >
                  Save
                </button>
                <button
                  type='button'
                  className='btn btn-dark submit-btn'
                  onClick={() => navigate('/jobs')}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default AddCandidate
