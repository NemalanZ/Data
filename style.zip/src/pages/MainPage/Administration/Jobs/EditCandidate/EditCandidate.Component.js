import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Select, Input, Upload, Button, Space } from 'antd'
import { map } from 'ramda'
import { UploadOutlined } from '@ant-design/icons';

const EditCandidate = ({
  fetchPrevCandidateDetails,
  candidateId,
  firstName,
  lastName,
  gender,
  emailId,
  phone,
  experience,
  mainSkill,
  secondarySkill,
  address,
  city,
  pinCode,
  state,
  country,
  resume,
  fetchMasterData,
  skills,
  cities,
  states,
  countries,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setResume,
  putCandidate,
  candidateDetails,
  jobId,
  jobTitle,
  candidateRounds,
  candidateStatus,
  setJobTitle,
  setRounds,
  setStatus,
  rounds,
  status,
  jobDetails
}) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const options = map(item => ({ value: item.job_id, label: item.job_title }), jobDetails)

  // console.log(id)

  useEffect(() => {
    fetchMasterData()
    fetchPrevCandidateDetails(id)
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    putCandidate(id, navigate)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Edit Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Add Candidate</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'><Link to='/candidates'>Candidates</Link></li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* Page Header */}
            <form>
              <div className='row'>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>
                      Job Title
                    </label>
                    <Space
                      style={{
                        width: '100%'
                      }}
                      direction='vertical'
                    >
                      <Select
                        size='large'
                        mode='multiple'
                        allowClear
                        style={{
                          width: '100%'
                        }}
                        name='JobTitle'
                        placeholder='Select'
                        value={jobId}
                        onChange={value => setJobTitle(value)}
                        options={options}
                      />
                    </Space>
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>
                      First Name
                    </label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='firstName'
                      type='text'
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Last Name</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='lastName'
                      type='text'
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>
                      Gender
                    </label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={gender}
                      onChange={(value) => setGender(value)}
                      options={[
                        { value: 'Male', label: 'Male' },
                        { value: 'Female', label: 'Female' },
                      ]}
                    >
                    </Select>
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Contact</h4>
              </div>
              <div className='row'>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Email</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='email'
                      type='email'
                      value={emailId}
                      onChange={(e) => setEmailId(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Phone</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='phone'
                      type='number'
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Address</h4>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <label>Address</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='address'
                      type='text'
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Pin Code</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='pinCode'
                      type='number'
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>City</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={city}
                      onChange={(value) => {
                        setCity(value)
                      }}
                      options={map(item => ({ value: item.city_id, label: item.city_name }), cities)}
                    >
                    </Select>
                  </div>
                </div>

                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>State</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={state}
                      onChange={(value) => setState(value)}
                      options={map(item => ({ value: item.state_id, label: item.state_name }), states)}
                    >
                    </Select>
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Country</label>
                    <label>Country</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={country}
                      onChange={(value) => setCountry(value)}
                      options={map(item => ({ value: item.country_id, label: item.country_name }), countries)}
                    >
                    </Select>
                  </div>
                </div>
              </div>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Experience & Skills</h4>
              </div>
              <div className='row'>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Year of Experience</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='experience'
                      type='text'
                      value={experience}
                      onChange={(e) => setExperience(e.target.value)}
                    />
                  </div>
                </div>

                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Main Skill</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={mainSkill}
                      onChange={(value) => setMainSkill(value)}
                      options={map(item => ({ value: item.skill_id, label: item.skill_name }), skills)}
                    >
                    </Select>
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Secondary Skill</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='secondarySkill'
                      type='text'
                      value={secondarySkill}
                      onChange={(e) => setSecondarySkill(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              {/* <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Status</h4>
              </div> */}
              {/* <div className='row'>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Rounds</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={rounds}
                      onChange={(value) => setRounds(value)}
                      options={map(item => ({ value: item.selection_status_id, label: item.selection_status_name }), candidateRounds)}
                      placement="bottomRight"
                    >
                    </Select>
                  </div>
                </div>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>Status</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={status}
                      onChange={(value) => setStatus(value)}
                      options={map(item => ({ value: item.profile_status_id, label: item.profile_status_name }), candidateStatus)}
                    >
                    </Select>
                  </div>
                </div>
              </div> */}
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Resume</h4>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <label>Resume</label>
                    <Space direction="horizontal" size="middle" style={{ paddingLeft: '10px' }}>
                      <Upload
                        listType="picture"
                      // value={resume}
                      // onChange={(value) => setResume(value)}
                      >
                        <Button icon={<UploadOutlined />}>Click to upload</Button>
                      </Upload>
                    </Space>
                    {/* <input
                      className='form-control'
                      type='file'
                      id='fileInput'
                      // value={resume}
                      onChange={e => setResume(e.target.value)}
                      accept='.pdf'
                    // required
                    /> */}
                  </div>
                </div>
              </div>
              <div className='submit-section'>
                <button
                  type='button'
                  className='btn btn-primary submit-btn'
                  onClick={handleSubmit}
                >Save
                </button>
                <button
                  type='button'
                  className='btn btn-dark submit-btn'
                  onClick={() => navigate('/candidates')}
                >Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default EditCandidate
