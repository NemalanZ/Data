import axios from 'axios'

const url = 'https://qbothrportal.azurewebsites.net/api/Login/validateUser'

const loginApi = async (userData) => {
  const response = await axios.post(url, userData)
  return response.data
}

export default loginApi
