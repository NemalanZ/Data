import axios from './getAxios'

export default async (payload) => {
  const { data } = await axios({
    method: 'POST',
    url: 'candidateDetails/saveCandidateDetails',
    data: payload
  })
  return data
}
