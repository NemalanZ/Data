import React, { useState, useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate, useParams, useLocation } from 'react-router-dom'
import { DeleteTwoTone, EditTwoTone } from '@ant-design/icons'
import { Popconfirm, Space, Table } from 'antd'

const EditCandidate = ({
  fetchCandidateDetails,
  candidateId,
  firstName,
  lastName,
  gender,
  emailId,
  phone,
  experience,
  mainSkill,
  secondarySkill,
  address,
  city,
  pinCode,
  state,
  country,
  resume,
  fetchMasterData,
  skills,
  cities,
  states,
  countries,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setResume,
  putCandidate,
  jobTitle,
  candidateRounds,
  candidateStatus
}) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const [gridData, setgridData] = useState([])

  console.log(candidateRounds)

  useEffect(() => {
    fetchCandidateDetails(location.state)
  }, [location.state])

  const handleSubmit = (e) => {
    e.preventDefault()
    putCandidate(id, navigate)
  }

  const dataWithDetails = gridData.map((details, index) => ({
    ...details,
    key: index,
    id: details.candidate_id,
    name: `${details.first_name} ${details.last_name}`,
    // role: details.gridData.role,
    experience: `${details.experience}`,
    location: `${details.city_name}, ${details.state_name}`,
    emailId: details.email,
    phone: details.contact_no,
    rounds: details.selection_status_name,
    status: details.profile_status_name
  }))

  const handleDelete = async (id) => {
    // deleteCandidate(id)
  }

  const columns = [
    {
      title: 'Job Title',
      dataIndex: 'jobTitle'
    },
    {
      title: 'Applied On',
      dataIndex: 'phone'
    },
    {
      title: 'Rounds',
      dataIndex: 'rounds'
    },
    {
      title: 'Status',
      dataIndex: 'status',
      render(text, record) {
        return {
          props: {
            style: {
              color:
                record.status === 'Selected'
                  ? 'green'
                  : record.status === 'Not Selected'
                    ? 'red'
                    : record.status === 'Decision Pending'
                      ? '#f3b800'
                      : 'white'
            }
          },
          children: <div>{text}</div>
        }
      },
      filters: [
        {
          text: 'Selected',
          value: 'Selected'
        },
        {
          text: 'Decision Pending',
          value: 'Decision Pending'
        },
        {
          text: 'Not Selected',
          value: 'Not Selected'
        }
      ],
      onFilter: (value, record) => record.status.indexOf(value) === 0,
      filterMultiple: false
    },
    {
      title: 'Action',
      dataIndex: 'action',
      render: (_, record) => (
        <Space>
          <Popconfirm
            title='Are you sure want to delete ?'
            onConfirm={() => {
              handleDelete(record.id)
            }}
          >
            <DeleteTwoTone style={{ color: 'red' }} />
          </Popconfirm>
        </Space>
      )
    }
  ]

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Edit Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-6'>
                  <h3 className='page-title'>Add Candidate</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'><Link to='/candidates'>Candidates</Link></li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
                <div className='col-sm-6'>
                  <div className='submit-section-detail'>
                    <button
                      type='button'
                      className='btn btn-dark submit-btn'
                      onClick={() => navigate(`/candidates/editCandidate/${location.state}`)}
                    >Edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
            {/* Page Header */}
            <fieldset disabled>
              <form>
                <div className='row'>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>
                        Job Title
                      </label>
                      <input
                        name='jobTitle'
                        className='form-control'
                        type='text'
                        value={jobTitle}
                        onChange={e => setFirstName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>
                        First Name
                      </label>
                      <input
                        name='firstName'
                        className='form-control'
                        type='text'
                        value={firstName}
                        onChange={e => setFirstName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Last Name</label>
                      <input
                        name='lastName'
                        value={lastName}
                        className='form-control '
                        type='text'
                        onChange={e => setLastName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>
                        Gender
                      </label>
                      <select
                        name='gender'
                        className='form-control'
                        value={gender}
                        onChange={e => setGender(e.target.value)}
                        required
                      >
                        {/* <option
                        defaultValue='Select'
                        hidden
                      >
                        {" "}
                        Select{" "}
                      </option> */}
                        {/* <option>
                        Select
                      </option> */}
                        <option>Male</option>
                        <option>Female</option>
                        {/* <option>Other</option> */}
                      </select>
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Contact</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>Email</label>
                      <input
                        name='emailId'
                        value={emailId}
                        className='form-control '
                        type='email'
                        onChange={e => setEmailId(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>Phone</label>
                      <input
                        name='phone'
                        value={phone}
                        className='form-control'
                        type='number'
                        onChange={e => setPhone(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Address</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-12'>
                    <div className='form-group'>
                      <label>Address</label>
                      <input
                        name='address'
                        value={address}
                        className='form-control'
                        type='text'
                        onChange={e => setAddress(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className='row'>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Pin Code</label>
                      <input
                        name='state'
                        value={pinCode}
                        className='form-control'
                        type='text'
                        onChange={e => setPinCode(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>City</label>
                      <select
                        name='city'
                        value={city}
                        className='form-control'
                        onChange={e => {
                          setCity(e.target.value)
                          // setState(e.target.value);
                          // setCountry(e.target.value);
                        }}
                        required
                      >
                        <option
                          defaultValue='Select'
                          hidden
                        >
                          {' '}
                          Select{' '}
                        </option>
                        {/* {[
                        cities.map((get) => (
                          <option key={get.city_id} value={get.city_id}> {get.city_name}</option>
                        ))
                      ]} */}
                      </select>
                    </div>
                  </div>

                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>State</label>
                      <select
                        name='state'
                        value={state}
                        className='form-control'
                        onChange={e => setState(e.target.value)}
                      // disabled
                      >
                        <option
                          defaultValue='Select'
                          hidden
                        >
                          {' '}
                          Select{' '}
                        </option>
                        {/* {[
                        states.map((get) => (
                          <option key={get.state_id} value={get.state_id}> {get.state_name}</option>
                        ))
                      ]} */}
                      </select>
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Country</label>
                      <select
                        name='country'
                        value={country}
                        className='form-control'
                        onChange={e => setCountry(e.target.value)}
                      // disabled
                      >
                        <option
                          defaultValue='Select'
                          hidden
                        >
                          {' '}
                          Select{' '}
                        </option>
                        {/* {[
                        countries.map((get) => (
                          <option key={get.country_id} value={get.country_id}> {get.country_name}</option>
                        ))
                      ]} */}
                      </select>
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Experience & Skills</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Year of Experience</label>
                      <input
                        name='experience'
                        value={experience}
                        className='form-control'
                        type='text'
                        onChange={e => setExperience(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Main Skill</label>
                      <select
                        name='mainSkill'
                        value={mainSkill}
                        className='form-control'
                        onChange={e => setMainSkill(e.target.value)}
                        required
                      >
                        <option
                          defaultValue='Select'
                          hidden
                        >
                          {' '}
                          Select{' '}
                        </option>
                        {/* {[
                        skills.map((get) => (
                          <option key={get.skill_id} value={get.skill_id}> {get.skill_name}</option>
                        ))
                      ]} */}
                      </select>
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Secondary Skill</label>
                      <input
                        name='secondarySkill'
                        value={secondarySkill}
                        className='form-control'
                        type='text'
                        onChange={e => setSecondarySkill(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Status</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>
                        Rounds
                      </label>
                      <input
                        name='candidateRounds'
                        className='form-control'
                        type='text'
                        value={candidateRounds}
                        // onChange={e => setFirstName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>Status</label>
                      <input
                        name='candidateStatus'
                        value={candidateStatus}
                        className='form-control '
                        type='text'
                        onChange={e => setLastName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Resume</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-12'>
                    <div className='form-group'>
                      <label>Resume</label>
                      <input
                        className='form-control'
                        type='file'
                        id='fileInput'
                        // value={resume}
                        onChange={e => setResume(e.target.value)}
                        accept='.pdf'
                      // required
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Status</h4>
                </div>
                <div className='row'>
                  <Table
                    className='table-striped'
                    pagination={{
                      total: dataWithDetails.length,
                      showTotal: (total, range) =>
                        `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                      showSizeChanger: true,
                      // onShowSizeChange,
                      // itemRender,
                      onChange(current) {
                        setPage(current)
                      }
                    }}
                    style={{ overflowX: 'auto' }}
                    columns={columns}
                    // bordered
                    dataSource={dataWithDetails}
                  // rowKey={record => record.id}
                  // onChange={onChange}
                  />
                </div>
              </form>
            </fieldset>

          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default EditCandidate
