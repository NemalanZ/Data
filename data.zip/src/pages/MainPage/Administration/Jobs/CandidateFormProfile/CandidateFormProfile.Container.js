import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import {
  fetchCandidateDetails,
  getCandidateId,
  getFirstName,
  getLastName,
  getGender,
  getEmailId,
  getPhone,
  getExperience,
  getMainSkill,
  getSecondarySkill,
  getAddress,
  getCity,
  getPinCode,
  getStateValue,
  getCountry,
  getResume,
  getJobTitle,
  getCandidateRounds,
  getCandidateStatus
} from '../../../../../redux/reducers/candidateDetailsReducer'
import Component from './CandidateFormProfile.Component'

const mapStateToProps = createStructuredSelector({
  candidateId: getCandidateId,
  firstName: getFirstName,
  lastName: getLastName,
  gender: getGender,
  emailId: getEmailId,
  phone: getPhone,
  experience: getExperience,
  mainSkill: getMainSkill,
  secondarySkill: getSecondarySkill,
  address: getAddress,
  city: getCity,
  pinCode: getPinCode,
  state: getStateValue,
  country: getCountry,
  resume: getResume,
  jobTitle: getJobTitle,
  candidateRounds: getCandidateRounds,
  candidateStatus: getCandidateStatus
})

const mapDispatchToProps = {
  fetchCandidateDetails
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
