import axios from './getAxios'

export default async (id) => {
  const { data } = await axios({
    method: 'GET',
    url: `jobPost/getJobPostDetails?job_id=${id}`
  })
  return data
}
