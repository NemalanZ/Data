// CandidateListExternal

import { DeleteTwoTone, EditTwoTone } from '@ant-design/icons'
import { Popconfirm, Space, Table, Tooltip } from 'antd'
import 'antd/dist/antd'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link } from 'react-router-dom'
import { itemRender, onShowSizeChange } from '../../../paginationfunction'
// import "../../antdstyle.css";
// import profile from '../../../../data/db.json'

const CandidateListExternal = () => {
  const [values, setValues] = useState([])
  const [page] = useState(1)

  useEffect(() => {
    loadData()
  }, [])

  const url = 'http://localhost:9000/candidatelist'

  const loadData = async () => {
    const response = await axios.get(url)
    setValues(response.data)
  }

  const dataWithDetails = values.map((details) => ({
    ...details,
    key: details.id,
    id: details.id,
    name: `${details.values.firstName} ${details.values.lastName}`,
    role: details.values.role,
    experience: `${details.values.experience} Years`,
    location: `${details.values.city}, ${details.values.state}.`,
    emailId: details.values.emailId,
    phone: details.values.phone
  }))

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:9000/candidatelist/${id}`)
    // const filteredData = values.filter(item => item.id !== id);
    // setValues(filteredData);
    // console.log(filteredData)
    loadData()
  }

  const columns = [
    {
      title: 'Id',
      key: 'serial',
      dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Name',
      dataIndex: 'name',
      editTable: true,
      render: (_, record) => (
        <Link to={`/app/administrator/candidate-profile/${record.id}`}>{record.name}</Link>
      ),
      sorter: (a, b) => a.name.length - b.name.length
    },
    {
      title: 'Job Title',
      dataIndex: 'role',
      sorter: (a, b) => a.role.length - b.role.length
    },
    {
      title: 'Experience',
      dataIndex: 'experience',
      sorter: (a, b) => a.experience.length - b.experience.length
    },
    {
      title: 'Location',
      dataIndex: 'location',
      sorter: (a, b) => a.location.length - b.location.length
    },
    {
      title: 'Email',
      dataIndex: 'emailId',
      sorter: (a, b) => a.emailId.length - b.emailId.length
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      sorter: (a, b) => a.phone.length - b.phone.length
    },

    {
      title: 'Action',
      dataIndex: 'action',
      render: (_, record) => (
        <Space>
          <Popconfirm
            title='Are you sure want to delete ?'
            onConfirm={() => handleDelete(record.id)}
          >
            <DeleteTwoTone />
          </Popconfirm>
          <Link to={`/app/administrator/update-candidate-external/${record.id}`}>
            <Tooltip title='help'><EditTwoTone /></Tooltip>

          </Link>
        </Space>
      )
    }
  ]
  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Candidate List - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        {/* Page Header */}
        <div className='page-header'>
          <div className='row align-items-center'>
            <div className='col'>
              <h3 className='page-title'>Candidate List</h3>
              {/* <ul className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/app/main/dashboard">Dashboard</Link>
                </li>
                <li className="breadcrumb-item active">Candidate List</li>
              </ul> */}
            </div>
            <div className='col-auto float-end ml-auto'>
              <Link
                to='/app/administrator/add-candidate'
                className='btn add-btn'
              >
                <i className='fa fa-plus' />
                Add Candidate
              </Link>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        <div className='row'>
          <div className='col-md-12'>
            <div className='table-responsive'>
              <Table
                className='table-striped'
                pagination={{
                  total: dataWithDetails.length,
                  showTotal: (total, range) =>
                    `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                  showSizeChanger: true,
                  onShowSizeChange,
                  itemRender
                }}
                style={{ overflowX: 'auto' }}
                columns={columns}
                // bordered
                dataSource={dataWithDetails}

              // rowKey={record => record.id}
              // onChange={this.handleTableChange}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CandidateListExternal
