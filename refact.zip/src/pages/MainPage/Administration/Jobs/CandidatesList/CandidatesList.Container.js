import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import { fetchAllCandidates, getAllCandidates, deleteCandidate, getCandidateStatus, fetchCandidatesStatus } from '../../../../../redux/reducers/candidatesReducer'
import Component from './CandidatesList.Component'

const mapStateToProps = createStructuredSelector({
  allCandidates: getAllCandidates,
  candidateStatus: getCandidateStatus
})

const mapDispatchToProps = {
  fetchAllCandidates,
  deleteCandidate,
  fetchCandidatesStatus
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
