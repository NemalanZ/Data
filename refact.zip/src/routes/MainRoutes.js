import React, { lazy } from 'react'
import SuspenseLoader from '../components/SuspenseLoader'

const MainPage = SuspenseLoader(lazy(() => import('../app/Layout/DefaultLayout')))

const DashBoardPage = SuspenseLoader(lazy(() => import('../pages/MainPage/Main/Dashboard/JobDashboard')))

const JobPage = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/ManageJobs')))
const ExternalJobPage = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/External/requisitionExternal')))
const JobDetails = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/JobFormDetail')))
const AddJobs = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/AddJobs')))
const EditJob = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/EditJob')))
const AddCandidateJob = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/AddCandidateJob')))

const CandidatePage = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/CandidatesList')))
const CandidateDetails = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/CandidateFormProfile')))
const AddCandidate = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/AddCandidate')))
const EditCandidate = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/EditCandidate')))

const ManageResumesPage = SuspenseLoader(lazy(() => import('../pages/MainPage/Administration/Jobs/manageresumes')))

const ErrorPage = SuspenseLoader(lazy(() => import('../pages/MainPage/Pages/ErrorPage/error404')))

const MainRoutes = {
  path: '/',
  element: <MainPage />,
  children: [
    {
      path: 'dashboard',
      element: <DashBoardPage />
    },
    {
      path: 'jobs',
      children: [
        {
          index: true,
          element: <JobPage />
        },
        {
          path: 'externalJobs',
          element: <ExternalJobPage />
        },
        {
          path: 'jobDetails/:id?',
          children: [
            {
              index: true,
              element: <JobDetails />
            },
            {
              path: 'addCandidate',
              element: <AddCandidateJob />
            }
          ]
        },
        {
          path: 'addJob',
          element: <AddJobs />
        },
        {
          path: 'editJob/:id?',
          element: <EditJob />
        }
      ]
    },
    {
      path: 'candidates',
      children: [
        {
          index: true,
          element: <CandidatePage />
        },
        {
          path: 'candidateProfile/:id?',
          element: <CandidateDetails />
        },
        {
          path: 'addCandidate',
          element: <AddCandidate />
        },
        {
          path: 'editCandidate/:id?',
          element: <EditCandidate />
        }
      ]
    },
    {
      path: 'manageResumes',
      element: <ManageResumesPage />
    },
    {
      path: '*',
      element: <ErrorPage />
    }
  ]
}

export default MainRoutes
