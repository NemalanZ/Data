import { createSelector } from 'reselect'
import { prop } from 'ramda'
import { JOB_DETAILS_ACTION as ACTIONS } from '../actions'
import getJobDetailsApi from '../../api/getJobDetails'

const initialState = {
  error: null,
  loading: false,
  jobDetails: {},
  jobId: '',
  requisitionId: '',
  dateOfRequisition: '',
  jobTitle: '',
  jobType: '',
  jobStatus: '',
  client: '',
  address: '',
  city: '',
  pinCode: '',
  country: '',
  state: '',
  experience: '',
  vacancyCount: '',
  minSalary: '',
  maxSalary: '',
  jobDescriptionFilePath: '',
  jobDescriptionText: '',
  archived: ''
}

const getSlice = prop('jobDetails')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getJobDetails = createSelector(getSlice, prop('jobDetails'))
export const getJobId = createSelector(getSlice, prop('jobId'))
export const getRequisitionId = createSelector(getSlice, prop('requisitionId'))
export const getDateOfRequisition = createSelector(getSlice, prop('dateOfRequisition'))
export const getJobTitle = createSelector(getSlice, prop('jobTitle'))
export const getJobType = createSelector(getSlice, prop('jobType'))
export const getJobStatus = createSelector(getSlice, prop('jobStatus'))
export const getClient = createSelector(getSlice, prop('client'))
export const getAddress = createSelector(getSlice, prop('address'))
export const getCity = createSelector(getSlice, prop('city'))
export const getPinCode = createSelector(getSlice, prop('pinCode'))
export const getStateValue = createSelector(getSlice, prop('state'))
export const getCountry = createSelector(getSlice, prop('country'))
export const getExperience = createSelector(getSlice, prop('experience'))
export const getVacancyCount = createSelector(getSlice, prop('vacancyCount'))
export const getMinSalary = createSelector(getSlice, prop('minSalary'))
export const getMaxSalary = createSelector(getSlice, prop('maxSalary'))
export const getJobDescriptionFilePath = createSelector(getSlice, prop('jobDescriptionFilePath'))
export const getJobDescriptionText = createSelector(getSlice, prop('jobDescriptionText'))
export const getArchived = createSelector(getSlice, prop('archived'))

export const fetchJobDetails = (id) => async (dispatch, getState) => {
  dispatch({
    type: ACTIONS.GET_JOB_DETAILS_REQUEST
  })
  try {
    const jobDetailsData = await getJobDetailsApi(id)
    dispatch({
      type: ACTIONS.GET_JOB_DETAILS_SUCCESS,
      data: jobDetailsData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.GET_JOB_DETAILS_FAILURE,
      error
    })
  };
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.GET_JOB_DETAILS_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.GET_JOB_DETAILS_SUCCESS: {
      return {
        ...state,
        jobDetails: action.data,
        jobId: prop('job_id', action.data),
        requisitionId: prop('requisition_id', action.data),
        dateOfRequisition: prop('date_of_requisition', action.data),
        jobTitle: prop('job_title', action.data),
        jobType: prop('job_type_name', action.data),
        jobStatus: prop('job_status', action.data),
        client: prop('company_name', action.data),
        address: prop('address', action.data),
        city: prop('city_name', action.data),
        pinCode: prop('pin_code', action.data),
        country: prop('country_name', action.data),
        state: prop('state_name', action.data),
        experience: prop('experience', action.data),
        vacancyCount: prop('vacancy_count', action.data),
        minSalary: prop('min_salary', action.data),
        maxSalary: prop('max_salary', action.data),
        jobDescriptionFilePath: prop('job_description_file_path', action.data),
        jobDescriptionText: prop('job_description_text', action.data),
        archived: prop('archived', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.GET_JOB_DETAILS_FAILURE: {
      return {
        ...state,
        error: action.error,
        location: false
      }
    }
    default:
      return initialState
  }
}
