import { createSelector } from 'reselect'
import { prop, reverse } from 'ramda'
import { DASHBOARD_ACTION as ACTIONS } from '../actions'
import getAllJobsApi from '../../api/getAllJobs'
import getAllCandidatesApi from '../../api/getAllCandidates'
import getClientApi from '../../api/getClient'

const initialState = {
  error: null,
  loading: false,
  allJobs: [],
  allCandidates: [],
  allClients: [],
  sliceJobs: [],
  sliceCandidates: []
}

const getSlice = prop('dashboard')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getAllJobs = createSelector(getSlice, prop('allJobs'))
export const getAllCandidates = createSelector(getSlice, prop('allCandidates'))
export const getAllClients = createSelector(getSlice, prop('allClients'))
export const getSliceJobs = createSelector(getSlice, prop('sliceJobs'))
export const getSliceCandidates = createSelector(getSlice, prop('sliceCandidates'))

export const fetchDashboardData = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.DASHBOARD_ACTION_REQUEST
  })
  try {
    const alljobsData = await getAllJobsApi()
    const allCandidatesData = await getAllCandidatesApi()
    const allClientData = await getClientApi()
    dispatch({
      type: ACTIONS.DASHBOARD_ACTION_SUCCESS,
      jobsData: alljobsData,
      candidatesData: allCandidatesData,
      clientsData: allClientData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.DASHBOARD_ACTION_FAILURE,
      error
    })
  }
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.DASHBOARD_ACTION_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.DASHBOARD_ACTION_SUCCESS: {
      return {
        ...state,
        allJobs: reverse(action.jobsData),
        allCandidates: reverse(action.candidatesData),
        allClients: action.clientsData,
        sliceJobs: reverse(action.jobsData).slice(0, 5),
        sliceCandidates: reverse(action.candidatesData).slice(0, 5),
        loading: false,
        error: false
      }
    }
    case ACTIONS.DASHBOARD_ACTION_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    default:
      return initialState
  }
}
