import { prop, reverse } from 'ramda'
import { createSelector } from 'reselect'
import deleteCandidateApi from '../../api/deleteCandidate'
import getAllCandidatesApi from '../../api/getAllCandidates'
import getCandidateStatusApi from '../../api/getCandidateStatus'
import { CANDIDATES_ACTION as ACTIONS } from '../actions'

const initialState = {
  error: null,
  loading: false,
  allCandidates: [],
  candidateStatus: []
}

const getSlice = prop('candidates')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getAllCandidates = createSelector(getSlice, prop('allCandidates'))
export const getCandidateStatus = createSelector(
  getSlice,
  prop('candidateStatus')
)

export const fetchAllCandidates = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.GET_ALL_CANDIDATE_REQUEST
  })
  try {
    const allCandidatesData = await getAllCandidatesApi()
    // console.log("allCandidatesData==>", allCandidatesData);
    dispatch({
      type: ACTIONS.GET_ALL_CANDIDATE_SUCCESS,
      data: allCandidatesData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.GET_ALL_CANDIDATE_FAILURE,
      error
    })
  }
}

export const fetchCandidatesStatus = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.GET_CANDIDATE_STATUS_REQUEST
  })
  try {
    const allCandidateStatusData = await getCandidateStatusApi()
    // console.log('allCandidateStatusData==>', allCandidateStatusData)
    dispatch({
      type: ACTIONS.GET_CANDIDATE_STATUS_SUCCESS,
      data: allCandidateStatusData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.GET_CANDIDATE_STATUS_FAILURE,
      error
    })
  }
}

export const deleteCandidate = (id) => async (dispatch) => {
  dispatch({
    type: ACTIONS.DELETE_CANDIDATE_REQUEST
  })
  try {
    const deleteCandidateData = await deleteCandidateApi(id)
    dispatch({
      type: ACTIONS.DELETE_CANDIDATE_SUCCESS,
      data: deleteCandidateData
    })
    dispatch(fetchAllCandidates())
  } catch (error) {
    dispatch({
      type: ACTIONS.DELETE_CANDIDATE_FAILURE,
      error
    })
  }
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.GET_ALL_CANDIDATE_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.GET_ALL_CANDIDATE_SUCCESS: {
      return {
        ...state,
        allCandidates: reverse(action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.GET_ALL_CANDIDATE_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.GET_CANDIDATE_STATUS_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.GET_CANDIDATE_STATUS_SUCCESS: {
      return {
        ...state,
        candidateStatus: action.data,
        loading: false,
        error: false
      }
    }
    case ACTIONS.DELETE_CANDIDATE_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.DELETE_CANDIDATE_SUCCESS: {
      return {
        ...state,
        loading: false,
        error: false
      }
    }
    case ACTIONS.DELETE_CANDIDATE_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    default:
      return initialState
  }
}
