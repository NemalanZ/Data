import axios from './getAxios'

export default async () => {
  const { data } = await axios({
    method: 'GET',
    url: 'jobPost/getClientDetails'
  })
  return data
}
