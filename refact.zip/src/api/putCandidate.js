import axios from './getAxios'

export default async (payload, id) => {
  const { data } = await axios({
    method: 'POST',
    url: `candidateDetails/saveCandidateDetails?candidate_id=${id}`,
    data: payload
  })
  return data
}
