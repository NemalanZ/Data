import axios from './getAxios'

export default async (payload, id) => {
  const { data } = await axios({
    headers: { 'Content-Type': 'application/json' },
    method: 'POST',
    url: `jobPost/saveJobPosts?job_id=${id}`,
    data: payload
    // data: JSON.stringify(payload)
  })
  return data
}
