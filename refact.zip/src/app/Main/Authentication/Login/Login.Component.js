import React, { useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate } from 'react-router-dom'
import IMAGEROUTER from '../../../../routes/ImgRouters'
import { useForm } from 'react-hook-form'
import { emailrgx } from '../../../../constant'
import { Input, Form, Button, Space, Row, Col } from 'antd'

const LoginComponent = ({ loginRedux, userName }) => {
  const [successMsg] = useState('')
  const [formData, setFormData] = useState({})
  const { emailId, password } = formData

  const navigate = useNavigate()

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const loginUser = () => {
    loginRedux(emailId, password, navigate)
  }
  console.log('loginUser')

  const {
    formState: { errors }
  } = useForm()


  return (
    <>
      <HelmetProvider>
        <Helmet>
          <title>Login - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      <div className='account-content'>
        {/* <Link to="/applyjob/joblist" className="btn btn-primary apply-btn">Apply Job</Link> */}
        <div className='container'>
          {/* Account Logo */}
          <div className='account-logo'>
            <Link to='/auth/login'>
              <img src={IMAGEROUTER.AppLogo} alt='Qbotica' />
            </Link>
          </div>
          {/* /Account Logo */}
          <div className='account-box'>
            <div className='account-wrapper'>
              <h3 className='account-title'>Login</h3>
              <p className='account-subtitle' />
              {/* Account Form */}
              <div>
                {/* <Form onSubmit={loginUser}> */}
                <Form
                  name="userForm"
                  layout={'vertical'}
                  style={{ maxWidth: 600 }}
                  colon={false}
                  requiredMark={false}
                  initialValues={{
                    remember: true
                  }}
                  onFinish={loginUser}
                >
                  <Row>
                    <Col span={24}>
                      <Form.Item
                        label={<label style={{ fontSize: '1rem' }}>Email Address</label>}
                        name="emailid"
                        rules={[
                          {
                            required: true,
                            message: 'Email Address required!',
                          },
                          {
                            pattern: "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",
                            message: "Invalid Email Id (examplemail@gmail.com)",
                          },
                          // {
                          //   validator: async (rule, value, pattern) => {
                          //     return new Promise((resolve, reject) => {
                          //       if (value === 'administrator@qbotica.com') {
                          //         resolve();
                          //       } else {
                          //         reject('Invalid Email Id')
                          //       }
                          //     });
                          //   }
                          // },
                        ]}
                      >
                        <Input
                          size='large'
                          style={{
                            width: '100%',
                            height: '50px',
                          }}
                          name='emailId'
                          type='emailId'
                          value={emailId}
                          onChange={handleInputChange}
                          autoComplete='off'
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Row>
                    <Col span={24}>
                      <Form.Item
                        label={<label
                          style={{ fontSize: '1rem' }}>Password

                        </label>}
                        name="password"
                        rules={[
                          {
                            required: true,
                            message: 'Password required!',
                          },
                          // {
                          //   validator: async (rule, value) => {
                          //     return new Promise((resolve, reject) => {
                          //       if (value === 'Admin@123') {
                          //         resolve();
                          //       } else {
                          //         reject('Invalid Password');
                          //       }
                          //     });
                          //   }
                          // },
                        ]}>
                        <Input.Password
                          size='large'
                          style={{
                            width: '100%',
                            height: '50px',
                          }}
                          name='password'
                          value={password}
                          onChange={handleInputChange}
                        />
                      </Form.Item>
                      <a className="login-form-forgot">
                        <Link
                          className='text-muted'
                          style={{
                            float: 'right',
                            // marginLeft: '226px' 
                          }} to='#'>
                          Forgot password?
                        </Link>
                      </a>
                    </Col>
                  </Row>
                  <Space
                    direction="vertical"
                    size="middle"
                    style={{
                      display: 'flex',
                      margin: '25px 0',
                    }}
                  >
                    <Row>
                      <Col span={24}>
                        <Button
                          style={{
                            width: '100%',
                            background: '#ff9b44',
                            border: '0',
                            borderRadius: '4px',
                            padding: '10px 26px',
                            height: '50px',
                            fontSize: '1.3rem',
                            color: 'white',
                          }}
                          className='btn btn-primary account-btn'
                          htmlType="submit"
                        // onClick={loginUser}
                        >
                          Login
                        </Button>
                      </Col>
                    </Row>
                  </Space>
                </Form>
                <div className='account-footer'>
                  <p>
                    Don't have an account yet?{' '}
                    <Link to='#'>Register</Link>
                  </p>
                </div>
              </div>
              {/* /Account Form */}
            </div>
          </div>
        </div>
      </div >
    </>
  )
}

export default LoginComponent
