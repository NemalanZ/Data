import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Scrollbar } from 'react-scrollbars-custom'

const Sidebar = () => {
  const [isSideMenu, setSideMenu] = useState('')

  const toggleSidebar = (value) => {
    // console.log (value);
    setSideMenu(value)
  }

  return (
    <div className='sidebar' id='sidebar'>
      <Scrollbar>
        <div className='sidebar-inner slimscroll'>
          <div id='sidebar-menu' className='sidebar-menu'>
            <ul>
              <li>
                <Link to='dashboard'>
                  <i className='la la-dashboard' /> <span>Dashboard</span>
                </Link>
              </li>
              {/* <li className="menu-title">
                <span>Administration</span>
              </li> */}
              <li className='submenu'>
                <a
                  href='#'
                  className={isSideMenu === 'jobs' ? 'subdrop' : 'subdrop'}
                  onClick={() =>
                    toggleSidebar(isSideMenu === 'jobs' ? '' : 'jobs')}
                >
                  <i className='la la-briefcase' /> <span> Jobs </span>{' '}
                  <span className='menu-arrow' />
                </a>
                {/* {isSideMenu == "jobs" ? */}
                <ul>
                  <li>
                    <Link
                      // className={'jobs' ? "active" : ""}
                      to='jobs'
                    >
                      Jobs List
                    </Link>
                  </li>
                  {/* <li><Link
                    // className={'jobs/externalJobs' ? "active" : ""}
                    to="jobs/externalJobs"
                  > Manage Jobs- External </Link></li> */}
                  <li>
                    <Link
                      // className={'candidates' ? "active" : ""}
                      to='candidates'
                    >
                      {' '}
                      Candidates List
                    </Link>
                  </li>
                  {/* <li><Link
                    // className={'' ? "active" : ""}
                    to="manage-resumes"
                  > Manage Resumes </Link></li> */}
                  {/* <li><Link className={pathname.includes('shortlist-candidates') ? "active" : ""} to="/app/administrator/shortlist-candidates"> Shortlist Candidates </Link></li> */}
                </ul>
                {/* : ""
                } */}
              </li>
              <li>
                {/* <Link to="/settings/companysetting"><i className="la la-cog" /> <span>Settings</span></Link> */}
              </li>
            </ul>
          </div>
        </div>
      </Scrollbar>
    </div>
  )
}

export default Sidebar
